<h1>reportes</h1>
<style type="text/css">
    #reportes{
        background-color: blue;
        padding: 10px;
        width: 100px;
        margin-left: 85%;
        color: white;
        border-radius: 5px;
        font-size: 1.2em;
    }
</style>

<a id="reportes" href="http://shalom.com/view/reportes2.php">Generar Reporte</a>

<div class="page-content-header">
    <div class="btn-group pull-right">

    </div>
    <h3>
        <i class="zmdi zmdi-map" style="color: red;"></i></i>
        Ventas
        <!-- <small>Listados</small> -->
    </h3>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="box box-blue">
                <div class="box-body">
                    <div class="table_responsive">
                      <table id="tab_venta" class="table table-bordered display" >
                           <thead>
                               <tr>
                                    <td>Id venta</td>
                                    <td>Pago</td>
                                    <td>Total_venta</td>
                                    <td>Cambio</td>
                                    <td>Fecha</td>
                                    <td>articulos vendidos</td>
                                   
                               </tr>
                           </thead>
                       </table>      
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- model content from here -->
 

