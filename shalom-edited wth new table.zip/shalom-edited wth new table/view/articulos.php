<div class="page-content-header">
    <div class="btn-group pull-right">
        <!-- <b><a href="./?view=form_alumno&accion=nuevo" class="btn btn-secondary btn-sm"><i class="fa fa-file-text-o fa-lg"></i></a></b> -->
        <button type="button" href="#Modal" class="btn btn-sm btn-dark" data-toggle="modal" >Nuevo</button>
        <!-- <b><a href="./view=xlsalumno" class="btn btn-secondary btn-sm"><i class="fa fa-download fa-lg"></i></a></b> -->
    </div>
    <h3>
        <i class="zmdi zmdi-store" style="color: orange;"></i>
       Articulos
        <!-- <small>Listados</small> -->
         <i class="zmdi zmdi-mall" style="color: purple;"></i>
    </h3>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="box box-blue">
                <div class="box-body">
                    <div class="table_responsive">
                      <table id="tab_articulos" class="table table-bordered display">
                           <thead>
                               <tr>
                                    <td>Codigo</td>
                                    <td>Clave</td>
                                    <td>Descripción</td>
                                    <td>Unidad</td>
                                    <td></i> <i class="fa fa-barcode fa-lg"></i></td>
                                    <td>$ Mayoreo</td>
                                    <td>$ Distribuidor</td>
                                    <td>$ Subdistribuidor</td>
                                    <td>$ Lista</td>
                                    <td>Marca</td>
                                    <!-- <td>Codigo SAT</td> -->
                                    <!-- <td>Descripción SAT</td> -->
                                    <td>Cantidad</td>
                                    <td></i> <i class="zmdi zmdi-settings zmdi-lg"></i></td>
                                    <!-- <td>Acciones</td> -->
                               </tr>
                           </thead>
                       </table>      
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- model content from here -->
       

        <div class="modal fade" id="Modal" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title" style="text-align: center;">Registro de Articulos</h6>
                        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button> -->
                    </div>
                    <div class="modal-body">
                        <!-- <form action="comprueba_login.php" method="post"> -->
                        <form id="form" method="post" onsubmit="return articulo();">
                        <!-- <form action="controller/proveedor.php?action=guardar" method="post"> -->
                            <div class="form-group">
                                <label for="codigo_articulo" class="form-control-label">Codigo del producto:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon">#</div>
                                    <input type="text" name="codigo_articulo" class="form-control" id="codigo_articulo">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="clave_articulo" class="form-control-label">Clave del producto:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon"><i class="zmdi zmdi-alert-circle"></i></div>
                                    <input type="text" name="clave_articulo" class="form-control" id="clave_articulo">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="descripcion_articulo" class="form-control-label">Descripción:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon"><i class="zmdi zmdi-wrap-text"></i></div>
                                    <input type="text" name="descripcion_articulo" class="form-control" id="descripcion_articulo">
                                 </div>
                            </div>
                            <div class="form-group">
                                <label for="unidad" class="form-control-label">Unidad:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon"><i class="zmdi zmdi-confirmation-number"></i></div>
                                    <input type="text" name="unidad" class="form-control" id="unidad">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="precio_m" class="form-control-label">Precio de mayoreo:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon"><i class="zmdi zmdi-money-off">M</i></div>
                                    <input type="text" name="precio_m" class="form-control" id="precio_m">
                                 </div>
                            </div>
                            <div class="form-group">
                                <label for="precio_d" class="form-control-label">Precio de distribuidor:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon"><i class="zmdi zmdi-money-off">D</i></div>
                                    <input type="text" name="precio_d" class="form-control" id="precio_d">
                                 </div>
                            </div>
                            <div class="form-group">
                                <label for="precio_s" class="form-control-label">Precio subdistribuidor:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon"><i class="zmdi zmdi-money-off">S</i></div>
                                    <input type="text" name="precio_s" class="form-control" id="precio_s">
                                 </div>
                            </div>
                            <div class="form-group">
                                <label for="precio_p" class="form-control-label">Precio de lista:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon"><i class="zmdi zmdi-money-off">L</i></div>
                                    <input type="text" name="precio_p" class="form-control" id="precio_p">
                                 </div>
                            </div>
                            <div class="form-group">
                                <label for="codigo_sat" class="form-control-label">Codigo del SAT:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon">#</div>
                                    <input type="text" name="codigo_sat" class="form-control" id="codigo_sat">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="descripcion_sat" class="form-control-label">Descripción Sat:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon"><i class="zmdi zmdi-file-text"></i></div>
                                    <input type="text" name="descripcion_sat" class="form-control" id="descripcion_sat">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="marca" class="form-control-label">Marca:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon"><i class="zmdi zmdi-comment-image"></i></div>
                                   <select  class="form-control" name="marca" id="marca">
                                            <option selected="" disabled="">--- Selecciona una opción ---</option>
                                            <?php
                                            require "model/consultas_general.php";
                                            $modelo = new consultas_general();
                                            $modelo = $modelo->getMarcas();
                                            foreach ($modelo as $I)
                                            {
                                            ?>
                                            <option value="<?php echo $I['id_marca']; ?>"><?php echo $I["nombre_marca"]; ?></option>
                                            <?php
                                            }
                                            ?>  
                                        </select>
                               </div> 
                            </div>
                            <div class="form-group">
                                <label for="cantidad" class="form-control-label">Cantidad en existencia:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon">C #</div>
                                    <input type="text" name="cantidad" class="form-control" id="cantidad">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="codigo_barra" class="form-control-label">Codigo de barra:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <div class="input-group-addon"><i class="fa fa-barcode"></i></div>
                                    <input type="text" name="codigo_barra" class="form-control" id="codigo_barra">
                                 </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" name="enviar" class="btn btn-primary">GUARDAR</button>
                                <button type="reset" class="btn btn-warning">BORRAR</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div
        </div>