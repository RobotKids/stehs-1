<?php 
    $host = "localhost";
            $user = "root";
            $password = "";
            $database = "pointsale";
            $charset = "utf8";
            $pdo = new pdo("mysql:host={$host};dbname={$database};charset={$charset}", $user, $password);
            
            @$barr_code=$_POST['barr_code'];
                                   
            if(isset($_POST['buscar'])){
            
           $consulta=$pdo->query("SELECT * FROM articulos where codigo_barra ='$barr_code' OR codigo_articulo = '$barr_code'");
           $busqueda=$consulta->fetch();
        }
    
?>

<?php
    require("model/suma.php");
    $suma = @Sumas::suma();
    // $I = @Sumas::getArticulo($_GET["codigo_articulo"]);
    if(isset($_POST['precio'])){
        $y = @Sumas::yes();
    }
    
?>
<!-- /////////////////////////////// -->
<section class="content">

    <style type="text/css">
              .row{
                  margin-left: 4px;
              }
    </style>
    <div class='row'>
      <!---  FORMULARIO 1--> 
        <style type="text/css">
                #caja1{
                    box-shadow: 0 0 20px 1px rgba(0,0,0,0.9);/** sombra fromulario**/
                }
                .ingresa{
                    padding-top: 2%;
                    text-align: center;
                }
            </style>  
            <div class='col-md-4' >
          <div class='box box-blue' id="caja1">
            <!--  -->
            <br><br>
            <!--  -->
          <form id="" method="post" >
                        <div>
                            <!-- <label for="" class="label" id=""><b>Barrcode:</b></label> -->
                            <input type="text" name="barr_code" id="barr_code" class="input" value="" ><input name="buscar" type="submit" value="Search" class="btn btn-primary">
                        </div>
                    </form>
          <form id="form" method="post" onsubmit="return preventa();" name="oi">
          <div class=''><h2 class="ingresa"><b>Preventa</b></h2></div>
          <div class='box-body'>
          <div class='input-group'>
          <div class='input-group-btn'>
          </div>
          <input type='text' id='codigo_barra' class='form-control d-none' name="codigo_barra" placeholder='Codigo...' value="<?php echo $busqueda["codigo_barra"]; ?>" style="font-size:20px; text-align:center; color:blue; font-weight: bold;">
          </div>
          <div class="form-control" onclick="calcula_monto(),yes()" >
          <!-- <div class="form-control" onclick="calcula_monto()" > -->
          <div class='input-group'>
          <span class='input-group-addon' style="background-color: red; color: white;">Precio:</span>
          <select  class="form-control" name="precio" id="precio" style="font-size:16px;  text-align:center; color:blue; font-weight: bold;">
                                            <?php
                                       
                                            {
                                            ?>
                                            <option value="<?php echo $busqueda['precio_m']; ?>"><?php echo @$busqueda["precio_m"]; ?> Mayoreo</option>
                                            <option value="<?php echo $busqueda['precio_d']; ?>"><?php echo @$busqueda["precio_d"]; ?> Distribuidor</option>
                                            <option value="<?php echo $busqueda['precio_s']; ?>"><?php echo @$busqueda["precio_s"]; ?> Subdistribuidor</option>
                                            <option value="<?php echo $busqueda['precio_p']; ?>"><?php echo @$busqueda["precio_p"]; ?> Publico</option>
                                            <?php
                                            }
                                            ?>  
                                        </select>
          </div>
          <br>
          
          <div class='input-group'>
          <span class='input-group-addon bg-orange' style="background-color: orange; color: white;" >Cantidad:</span>
          <input type='text' id='cantidad' class='form-control' name="cantidad" style="font-size:20px; text-align:center; color:blue; font-weight: bold;"
          data-inputmask="'alias': 'numeric', 'autoGroup': true, 'digits': 2, 'digitsOptional': false, 'placeholder': '0'" value="" >
          </div>
          <div>
              <input type="text" id="existencia_a" class='form-control d-none' value="<?php echo @$busqueda["cantidad"]; ?>">
              <input type="text" id="result_E" class='form-control d-none' name="result_E">
          </div>
           
          <br>
          <div class='input-group'>
          <span  class='input-group-addon bg-orange' style="background-color: green; color: white;" >Monto:</span>
          <input type='text' id='monto' class='form-control' name="monto" style="font-size:20px; text-align:center; color:blue; font-weight: bold;"
          data-inputmask="'alias': 'numeric', 'autoGroup': true, 'digits': 2, 'digitsOptional': false, 'placeholder': '0'" value="" >
          </div>
        </div>
          <br>
          
          <button  type="submit" name="enviarA" class='btn btn-success btn-lg' ><i class="zmdi zmdi-shopping-cart" ></i>Agregar</button>
          <form action="" method="post">
          <a href="./?view=ventas" class="btn btn-lg btn-warning" id="recarga" name="bor" ><i class="zmdi zmdi-wifi-off"></i> Borrar</a>
          </form>
          </div>
        </form>
          </div>
        </div>             

     
<!-- ////////////////////////////////////////////////////////////////////////////////////////////// -->
<!---  FORMULARIO 2-->
        <style type="text/css">
                #caja11{
                    padding-bottom: 9%;
                    box-shadow: 0 0 20px 1px rgba(0,0,0,0.9);/** sombra fromulario**/
                    margin-left: 6%;
                }
                #formulario{
                    display: flex;
                    padding-top: 6%;
                    text-align: center;
                    justify-content: space-between;
                    padding-bottom: 2%;
                    
                }
                #descripcion{
                    /** background-color: red;**/
                    width: 48%;
                    display:inline-block;
                    
                }
                #descripcion1{
                    /** background-color: red;**/
                    width: 48%;
                    display:inline-block;
                    
                }
                .azul{
                    background-color: dodgerblue;
                    margin: auto;
                    padding-top: 6%;
                    text-align: center;
                }
                #row{
                    margin: auto;
                    
                }
            </style>
            <div class="col-md-4" id="caja2">
              <div class=""id="caja11">
                  <div class="" id="row">
                  <div class="azul">
                        <h5>Descripción</h5>
                         <br>
                     </div>
                    <div id="formulario">
                      <div class="" id="descripcion">
                        <h5 class="description-header preciol">Artículo</h5>
                        <span class="description-text"><value="<?php echo @$busqueda["codigo_barra"]; ?>"><?php echo @$busqueda["descripcion_articulo"]; ?></span>
                         
                         
                         <!---  <input type="text" value="<?php echo @$busqueda["cantidad"]; ?>" id="barras">-->
                          
  
                    <p><?php echo @$registros['cod_articulo']?></p>
                        
                      </div>
                      <div class="" id="descripcion1">
                        <h5 class="description-header preciol">Existencias</h5>
                        <span class="description-text"><value="<?php echo @$busqueda["codigo_barra"]; ?>"><?php echo @$busqueda["cantidad"]; ?></span>
                      </div>
                    </div>
                  </div>
              </div>
            </div>
<!-- ////////////////////////////////////////////////////////////////////////////////////////////// -->
<!---  FORMULARIO 3-->
        <style type="text/css">
                #caja3{
                    box-shadow: 0 0 20px 1px rgba(0,0,0,0.9);/** sombra fromulario**/
                    margin-bottom: 22%;
                    margin-left: 3%;
                    width: 27%;
                  
                }
                .caja3-1{
                    width: 100%;
                    
                }
                .total{
                    text-align: center;
                    padding-top: 5%;
                    padding-bottom: 11%;
                    background-color:dodgerblue;
                }
                .precio{
                    margin-left: 4%;
                    padding-bottom: 2%;
                }
                .botons{
                    display: flex;
                    justify-content:space-around;
                    margin-top: 2%;
                    margin-bottom: 2%;
                }
                
            </style>  
            <div id="caja3">
              <div class="caja3-1">
                  <div id='totales'>
                      <h5 class="total">Total a pagar</h5> 
                  </div>
                  <div class="precio">
                   
                     <h2 id="total" value="ola">$ <?php echo $suma['Total']?></h2> 
                      
                      
                      
                  </div>
                  <div class="botons">
            <!---  boton PAGAR && CANCELAR -->
               
                <button name="manar"  class='btn  btn-success' id='btn-procesa' onclick="document.getElementById('id02').style.display='block'"><i class='fa fa-money' ></i>Pagar</button>
               
                <form method="post">
        <a href="http://shalom.com/view/vendor/pdf/tiket.php" class="btn btn-md btn-info" id="recarga" onclick='' disabled='true'><i class="zmdi zmdi-file-text"></i>Tiket</a>             
                
                <button class='btn  btn-warning' name="cancelar" type="submit"><i class='fa fa-times-circle' ></i>cancelar venta</button>
              </div>
              </div>
            </div>
<!-- ///////////////////////////////////////////////////////////////////////////////////////////// -->
<!---  TABLA PREVENTA-->
<div class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="box box-blue">
                <div class="box-body">
                    <div id="load_preventa">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 
<!-- /////////////////////////////////////////////////////////////////////////////////////// -->
<!---  Modal pagar-->
           <div class="modal" id="id02">
            <div class="col-md-4 animate">
                <div class="caja">
                    <form id="id01" method="post" >
                   <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
                    <div class="resumen">
                       <h4>RESUMEN</h4>
                    </div>
                    <div class="formulario" onclick="calcula_cambio()">
                      
                       <div>
                            <label for="" class="label" ><b>Total de venta:</b></label>
                            <input type="text" name="total_venta" id="total_venta" class="input" value="<?php echo $suma['Total']?>" >
                        </div>
                        <div>
                            <label for="" class="label" id="label2"><b>Su pago:</b></label>
                            <input type="text" name="pago" id="paga_con" class="input" value="0.00" >
                        </div>
                        <div>
                            <label for=""  class="label" id="label3"><b>Cambio:</b></label>
                            <input type="text" onclick="" class="input" id="el_cambio" value="0.00" name="cambio">
                        </div>
                        <div>
                            <input type="text" class='form-control d-none' id="existes" name="existe">
                        </div>
                        
                    </div>
                    <div class="botones">
                        <input name="insertar" type="submit" value="Procesar" class="btn btn-success btn-lg">
                        <button type="button" class='btn btn-danger btn-lg'onclick="document.getElementById('id02').style.display='none'">Cerrar</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <style>
          #id04{
            margin-left: 70%;
            margin-top: 10%;
          }
        </style>
<!-- ///////////////////////////////////////////////////////////////////////////////////////////// -->
<?php 
    $host = "localhost";
            $user = "root";
            $password = "";
            $database = "pointsale";
            $charset = "utf8";
            $pdo = new pdo("mysql:host={$host};dbname={$database};charset={$charset}", $user, $password);
            
            @$total_venta=$_POST['total_venta'];
            @$cambio=$_POST['cambio'];
            @$pago=$_POST['pago'];
                                   
    //----------- INICIA EXISTENCIAS-----------------//                                   
            // -------- SELECCIONAR ------//
                $numero=array();
                $consulta = $pdo->query("select cod_articulo from preventa");
                $registro=$consulta->fetchAll(PDO::FETCH_OBJ);
                foreach ($registro as $dato){
                   $numero[]=$dato->cod_articulo; 
                }
                
                for($i=0;$i<=count($numero);$i++){
                   @$numero2[$i]=$numero[$i];
                }
                $implo=implode(",",$numero2);
                
                $var="<script>
                    document.getElementById('existes').value='$implo';
                    
                      </script>";
                echo $var;
                 
                // ----- INSERTAR --------- //
                $lista =@$_POST['existe'];
                $caracteres = '( )';
                $caracteres = explode(',', $caracteres);
                $nchar = count($caracteres);
                $base = 0;
                while($base<$nchar){
                  $lista = str_replace($caracteres[$base],'',$lista);
                  $base++;
                }
                $array = explode(',', $lista);
                foreach($array as $idnum)
                 {
                 $codigo=trim($idnum,",");
                 $insertar=$pdo->query("UPDATE articulos SET cantidad = (select preventa.existencia from preventa where cod_articulo=$idnum) WHERE codigo_barra = $idnum");
                    //print $idnum;
                 }
    //-------------------- TERMINA EXISTENCIAS ----------------//
                                   
            if(isset($_POST['insertar'])){
            
           $insertarventa=$pdo->query("insert into ventas value(null,'$pago','$total_venta','$cambio',now())");
                
            if($insertarventa==true){
            $insertarUno=$pdo->query("INSERT INTO max (max) SELECT max(v.id_venta) FROM ventas as v");
            }
            if ($insertarUno==true){
                $insertarDos=$pdo->query("INSERT INTO productos_vendidos (venta,producto_vendido,cantidad_p,precio_pro,monto_p) SELECT m.max, pv.cod_articulo, pv.p_cantidad, pv.precio, pv.monto FROM max as m, preventa as pv");
           }
                
            if ($insertarDos==true){
         
                $insertarTres=$pdo->query("DELETE FROM max");
            }
            if ($insertarTres==true){
                $insertarCuatro=$pdo->query("DELETE FROM preventa");
                
            }if ($insertarCuatro==true){
                $insertarCinco=$pdo->query("DELETE FROM max2");
            }
            if ($insertarCinco==true){
                $insertarSeis=$pdo->query("INSERT INTO max2 (max2) SELECT max(v.id_venta) FROM  ventas as v");
            }

        }
        if(isset($_POST['cancelar'])){
            $cancelarventa=$pdo->query("DELETE FROM preventa");
        }
?>
           
<style type="text/css">
        .caja{
            background-color:white;
            width: 150%;
            margin-top: 10%;
            margin-left: 80%;
            padding-bottom: 30px;
            padding-left: 10%;
            box-shadow: 0 0 20px 1px rgba(0,0,0,5);/** sombra fromulario**/
        }    
       .formulario{
          /** background-color: yellow;**/
           display: flex;
           flex-direction: column;
           margin-left: 20px;
           
       }
       .input{
           width: 60%;
           font-size: 1.8em;
           margin-left: -1%;
           margin-bottom: 3%;
           color: red;
           font-weight:bold;
           text-align: center;
           
       }
       .label{
           color: white;
           background-color:mediumblue;
           font-size: 1.5em;
           padding-left: 20px;
           padding-right: 5px;
           padding-bottom:4px;
           padding-top: 8px;
       }
       #label2{
           padding-right: 65px;
           padding-bottom:4px;
           padding-top: 8px;
       }
       #label3{
          padding-right: 68px; 
          padding-bottom:4px;
          padding-top: 8px;
       }
       .botones{
           padding-left: 40%;
       }
       .resumen{
           margin-left: 4%;
           padding-top: 4%;
           padding-bottom: 4%; 
       }
       .modal {
            display: none; /* Hidden by default */
            background-color: rgba(0,0,0,0.7); /* Black w/ opacity */
            overflow: auto;
        }
       .close:hover{
           opacity: 0.8;
           cursor: pointer;
       }
       .animate {
            -webkit-animation: animatezoom 0.6s;
            animation: animatezoom 0.7s
        }
       @-webkit-keyframes animatezoom {
            from {-webkit-transform: scale(0)} 
            to {-webkit-transform: scale(1)}
        }
    
        @keyframes animatezoom {
            from {transform: scale(0)} 
            to {transform: scale(1)}
        }
    </style>
<!---  prueba ola-->

<script>
    function dato(){
        //var fecha=Date();
        document. getElementById("fecha").innerHTML = "New text!";
        
        }
</script>
<!---  script modal -->
<script>

var modal = document.getElementById('id02');
window.onclick = function(event) {
    if (event.target == modal) {
        alert("ola");
        modal.style.display = "none";
        
    }
}
</script>
<script>
    function calcula_cambio(){
   var m1=$("#total_venta").val();
   var m2=$("#paga_con").val();
   var change=parseFloat(m2)-parseFloat(m1);
   $("#el_cambio").val(change.toFixed(2));
}
</script>
<script>
    function calcula_monto(){
        var m1=$("#precio").val();
        var m2=$("#cantidad").val();
        var result=parseFloat(m1)*parseFloat(m2);
        $("#monto").val("$ "+result.toFixed(2));
    }
</script>
<script>
    function recarga_pagina(){
      var loadpage = document.getElementById('recarga');
      {
        loadpage.execute();
      }
    }
</script>
<script>
function yes(){
        var m1=$("#existencia_a").val();
        var m2=$("#cantidad").val();
        var result=parseInt(m1)-parseInt(m2);
        $("#result_E").val(result);
}
</script>