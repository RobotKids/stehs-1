<!DOCTYPE html>
<html>
<head>
	<title></title>

</head>
<body>
	<div class="row">
		<div class="col-md-4"></div>
		<div class="col-md-4">
			<center><h1>articulo</h1></center>
			<form method="POST" action="prueba.php"></form>
			<div class="form-group">
				<label for="codigo_barra">Bar code</label>
				<input type="text" name="codigo_barra" class="form-contrl" id="codigo_barra">
			</div>
			<div class="form-group">
				<label for="codigo_barra">Bar code</label>
				<input type="text" name="codigo_barra" class="form-contrl" id="codigo_barra">
			</div>
			<center>
				<input type="submit" value="Enviar" name="btn1" class="btn btn-success">
			</center>
		</div>

	</div>

</body>
</html>