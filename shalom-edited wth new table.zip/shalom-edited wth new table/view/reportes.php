<?php
	
	require 'Classes/PHPExcel.php';
	require 'conexions.php';
	
	$sql = "SELECT id_venta, total_venta, cambio, fecha FROM ventas";
	$resultado = $mysqli->query($sql);
	
	$fila = 2;
	
	$objPHPExcel = new PHPExcel();
	$objPHPExcel->getProperties()->setCreator("Codigos de Programacion")->setDescription("Reporte de Ventas");
	
	$objPHPExcel->setActiveSheetIndex(0);
	$objPHPExcel->getActiveSheet()->setTitle("Ventas");
	
	$objPHPExcel->getActiveSheet()->setCellValue('A1', 'ID');
	$objPHPExcel->getActiveSheet()->setCellValue('B1', 'VENTA');
	$objPHPExcel->getActiveSheet()->setCellValue('C1', 'CAMBIO');
	$objPHPExcel->getActiveSheet()->setCellValue('D1', 'FECHA');
	
	
	while($row = $resultado->fetch_assoc())
	{
		
		$objPHPExcel->getActiveSheet()->setCellValue('A'.$fila, $row['id_venta']);
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$fila, $row['total_venta']);
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$fila, $row['cambio']);
		$objPHPExcel->getActiveSheet()->setCellValue('D'.$fila, $row['fecha']);
		
		
		$fila++;
		
	}
	
	header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
	header('Content-Disposition: attachment;filename="Productos.xlsx"');
	header('Cache-Control: max-age=0');
	
	$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
	$objWriter->save('php://output');
	
?>