<?php
require("../model/preventa.php");
$preventas = Preventas::getPreventas();
if (count($preventas) > 0)
{
?>
<table class="table table-bordered text-center">
    <thead>
        <tr>
            <td><b>codigo del articulo</b></td>
            <td><b>Descripción</b></td>
            <td><b>Cantidad</b></td>
            <td><b>Precio</b></td>
            <td><b>Monto</b></td>
            <td></td>
        </tr>
    </thead>
    <tbody>
    <?php 
    foreach ($preventas as $preventa)
    {
    ?>
        <tr>
            <td><?php echo $preventa['cod_articulo']; ?></td>
            <td><?php echo $preventa['descripcion_articulo']; ?></td>
            <td><?php echo $preventa['p_cantidad']; ?></td>
            <td><?php echo $preventa['precio']; ?></td>
            <td><?php echo $preventa['monto']; ?></td>
            <td>
                 
                <?php echo "<a href=javascript:eliminarPreventas({$preventa['id_preventa']}) class='btn btn-danger btn-sm'><i class='fa fa-trash-o'></i></a>"; ?>                
            </td>   
        </tr>
    <?php
    }
    ?>
    </tbody>
</table>
<?php
}
else
{
    echo "<div class='alert alert-danger text-center'>
        No hay registros en la base de datos.
        </div>";
}
?>
<!--  -->