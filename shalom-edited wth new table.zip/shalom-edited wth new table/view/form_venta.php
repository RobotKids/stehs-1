<!-- <button type="button" href="#Modal" class="btn btn-sm btn-dark" data-toggle="modal" >SEARCH</button> -->
<?php
// if (isset($_GET["accion"]) && $_GET["accion"]=="editar"):
    // require "model/articulos.php";
     require "model/suma.php";
    $I = @Sumas::getArticulo($_GET["codigo_articulo"]);
    $suma = @Sumas::suma();
?>
    <div class="page-content-header">
        <!-- <h3>
            <i class="zmdi zmdi-book"></i>
        Articulo
        <small>Actualizar Datos</small>
        </h3> -->
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-0"></div>
            <div class="col-5">
                <div class="box box-blue">
                    <div class="box-body">
                        <!-- <button type="button" href="#Modal" class="btn btn-sm btn-dark" data-toggle="modal" >SEARCH</button> -->
                        <button class='btn  btn-success' onclick="document.getElementById('marticulo').style.display='block'" style="width:auto;"><i class='fa fa-money'></i>Pagar</button>
                        <form id="form" method="post" onsubmit="return preventa();">
                            <p class="text-secondary">Datos del Articulo</p>
                            <hr>
                            <div class="form-group">
                                <label for="codigo_barra" class="col-sm-2 col-form-label text-center">Codigo de barra:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="codigo_barra" name="codigo_barra" value="<?php echo $I["codigo_barra"]; ?>">
                                </div>
                            </div>
                            <div class="formulario" onclick="calcula_monto()">
                          <div class="form-group">
                                <label for="precio" class="col-sm-2 col-form-label text-center">Precio:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <!-- <div class="input-group-addon"><i class="zmdi zmdi-comment-image"></i></div> -->
                                   <select  class="form-control" name="precio" id="precio">
                                            <!-- <option selected="" disabled="">--- Selecciona una opción ---</option> -->
                                            <?php
                                            // require "model/consultas_general.php";
                                            // $modelo = new consultas_general();
                                            // $modelo = $modelo->getMarcas();
                                            // foreach ($articulo as $I)
                                            {
                                            ?>
                                            <option value="<?php echo $I['precio_m']; ?>"><?php echo $I["precio_m"]; ?></option>
                                            <option value="<?php echo $I['precio_d']; ?>"><?php echo $I["precio_d"]; ?></option>
                                            <option value="<?php echo $I['precio_s']; ?>"><?php echo $I["precio_s"]; ?></option>
                                            <option value="<?php echo $I['precio_p']; ?>"><?php echo $I["precio_p"]; ?></option>
                                            <?php
                                            }
                                            ?>  
                                        </select>
                               </div> 
                               <label for="cantidad" class="col-sm-2 col-form-label text-center">Cantidad:</label>
                                <div class="col-sm-10">
                                <input type="text" class="form-control" id="cantidad" name="cantidad" value="">
                                </div>
                                <label for="monto" class="col-sm-2 col-form-label text-center">Monto:</label>
                                <div class="col-sm-10">
                                <input type="text" class="form-control" id="monto" name="monto" value="">
                                </div>
                           </div>
                       </div>
                            <hr>
                            <div class="text-center">
                    <button type="submit" name="enviar" class="btn btn-primary btn-sm"><i class="zmdi zmdi-shopping-cart"></i>Agregar</button>
                    <a href="./?view=form_venta" class="btn btn-sm btn-warning"><i class="zmdi zmdi-wifi-off"></i> Borrar</a>

                            </div>
                         </form>
                    </div>
                </div>
            </div>
         </div>
    </div>

    <div class="col-md-4">
              <!-- Widget: user widget style 1 -->
              <div class="box box-widget widget-user">
                <!-- Add the bg color to the header using any of the bg-* classes -->
                <div class="widget-user-header bg-aqua-active">
                  <h3 class="widget-user-username"></h3>
                  <h class="widget-user-desc"></h1>
                </div>
                <div class="box-footer">
                  <div class="row">
                    <div class="col-sm-4 border-right">
                      <div class="description-block">
                        <h5 class="description-header preciol">0.00</h5>
                        <span class="description-text">PRECIO U. L.</span>
                      </div><!-- /.description-block -->
                    </div><!-- /.col -->
                    <div class="col-sm-4 border-right">
                      <div class="description-block">

                      </div><!-- /.description-block -->
                    </div><!-- /.col -->
                  </div><!-- /.row -->
                </div>
              </div><!-- /.widget-user -->
            </div>

                <!---  total a pagar-->
            <div class="col-md-4">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
                  <h3><div id='totales'></div></h3>
                  <p>Total</p>
                </div>
                <div class="icon">
                  <i class="fa fa-shopping-cart"></i>
                </div>
                <a href="#" class="small-box-footer">
                  <div id='num_ticket'></div>
                </a>
                <a href="#" class="small-box-footer">
                  <div id='total_articulos'></div>
                </a>
                <a href="#" class="small-box-footer">
                  <div id='tipo_de_venta'>Venta de Contado.</div>
                </a>
              </div>
              <div class='btn-group'>
              <!---  boton PAGAR && CANCELAR -->
                <button class='btn  btn-success' id='btn-procesa' onclick="document.getElementById('id02').style.display='block'" style="width:auto;"><i class='fa fa-money'></i>Pagar</button>
              
              <button class='btn  btn-warning' id='btn-cancela' onclick="cancela_venta();"><i class='fa fa-times-circle'></i> Cancelar</button>
              
              </div>
            </div>

    <div class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="box box-blue">
                <div class="box-body">
                    <div class="table_responsive">
                      <table id="tab_preventa" class="table table-bordered ">
                           <thead>
                               <tr>
                                    <td>Codigo_articulo</td>
                                    <td>Descripcion</td>
                                    <td>Cantidad</td>
                                    <td>Precio</td>
                                    <td>Monto</td>
                                    <td>Operacion</td>
                               </tr>
                           </thead>
                       </table>      
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    </div>

<!-- //////////////////////////////////////////////////////////// -->
<?php

?>
<!-- model content from here -->
       

        <div class="modal fade" id="Modal" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title" style="text-align: center;">Registro de Articulos</h6>
                        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button> -->
                    </div>
                    <div class="modal-body">
                        <!-- <form action="comprueba_login.php" method="post"> -->
                        <div class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="box box-blue">
                <div class="box-body">
                    <div class="table_responsive">
                      <table id="tab_articulos2" class="table table-bordered display">
                           <thead>
                               <tr>
                                    <td>Codigo</td>
                                    <!-- <td>Clave</td> -->
                                    <td>Descripción</td>
                                    <!-- <td>Unidad</td> -->
                                    <td></i> <i class="fa fa-barcode fa-lg"></i></td>
                                    <!-- <td>$ Mayoreo</td> -->
                                    <!-- <td>$ Distribuidor</td> -->
                                    <!-- <td>$ Subdistribuidor</td> -->
                                    <!-- <td>$ Lista</td> -->
                                    <!-- <td>Marca</td> -->
                                    <!-- <td>Codigo SAT</td> -->
                                    <!-- <td>Descripción SAT</td> -->
                                    <!-- <td>Cantidad</td> -->
                                    <td></i> <i class="zmdi zmdi-settings zmdi-lg"></i></td>
                                    <!-- <td>Acciones</td> -->
                               </tr>
                           </thead>
                       </table>      
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
                    </div>
                </div>
            </div
        </div>

<!-- shifus work -->
<!---  Modal pagar-->
           <div class="modal" id="id02">
            <div class="col-md-4 animate">
                <div class="caja">
                    <form id="id01" method="post" onsubmit="return ventas();">
                   <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
                    <div class="resumen">
                       <h4>RESUMEN</h4>
                    </div>
                    <div class="formulario" onclick="calcula_cambio()">
                      
                       <div>
                            <label for="" class="label" ><b>Total de venta:</b></label>
                            <input type="text" name="total_venta" id="total_venta" class="input" value="<?php echo $suma['Total']?>" >
                        </div>
                        <div>
                            <label for="" class="label" id="label2"><b>Su pago:</b></label>
                            <input type="text" id="paga_con" class="input" value="0.00" >
                        </div>
                        <div>
                            <label for="" class="label" id="label3"><b>Cambio:</b></label>
                            <input type="text" onclick="" class="input" id="el_cambio" value="$0.00" onclick="">
                        </div>
                        
                    </div>
                    <div class="botones">
                        <button type="submit" class='btn  btn-success btn-lg' >Procesar</button>
                        <button type="button" class='btn btn-danger btn-lg'onclick="document.getElementById('id02').style.display='none'">Cerrar</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>



<style type="text/css">
        .caja{
            background-color:white;
            width: 150%;
            margin-top: 10%;
            margin-left: 80%;
            padding-bottom: 30px;
            padding-left: 10%;
            box-shadow: 0 0 20px 1px rgba(0,0,0,5);/** sombra fromulario**/
        }    
       .formulario{
          /** background-color: yellow;**/
           display: flex;
           flex-direction: column;
           margin-left: 20px;
           
       }
       .input{
           width: 60%;
           font-size: 1.8em;
           margin-left: -1%;
           margin-bottom: 3%;
           color: red;
           font-weight:bold;
           text-align: center;
           
       }
       .label{
           color: white;
           background-color:mediumblue;
           font-size: 1.5em;
           padding-left: 20px;
           padding-right: 5px;
           padding-bottom:4px;
           padding-top: 8px;
       }
       #label2{
           padding-right: 65px;
           padding-bottom:4px;
           padding-top: 8px;
       }
       #label3{
          padding-right: 68px; 
          padding-bottom:4px;
          padding-top: 8px;
       }
       .botones{
           padding-left: 40%;
       }
       .resumen{
           margin-left: 4%;
           padding-top: 4%;
           padding-bottom: 4%; 
       }
       .modal {
            display: none; /* Hidden by default */
            background-color: rgba(0,0,0,0.7); /* Black w/ opacity */
            overflow: auto;
        }
       .close:hover{
           opacity: 0.8;
           cursor: pointer;
       }
       .animate {
            -webkit-animation: animatezoom 0.6s;
            animation: animatezoom 0.7s
        }
       @-webkit-keyframes animatezoom {
            from {-webkit-transform: scale(0)} 
            to {-webkit-transform: scale(1)}
        }
    
        @keyframes animatezoom {
            from {transform: scale(0)} 
            to {transform: scale(1)}
        }
    </style>
<script>
    function dato(){
        //var fecha=Date();
        document. getElementById("fecha").innerHTML = "New text!";
        
        }
</script>
<script>

var modal = document.getElementById('id02');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
<script>
    function calcula_cambio(){
   var m1=$("#total_venta").val();
   var m2=$("#paga_con").val();
   var change=parseFloat(m2)-parseFloat(m1);
   $("#el_cambio").val("$ "+change.toFixed(2));
}
</script>

        <!-- 

<button type="button" href="#Modal" class="btn btn-sm btn-dark" data-toggle="modal" >SEARCH</button>
         -->
<script>
    function calcula_monto(){
        var m1=$("#precio").val();
        var m2=$("#cantidad").val();
        var result=parseFloat(m1)*parseFloat(m2);
        $("#monto").val("$ "+result.toFixed(2));
    }
</script>

<script>

var modal = document.getElementById('marticulo');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

