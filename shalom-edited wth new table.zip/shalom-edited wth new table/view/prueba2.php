<?php 
    $host = "localhost";
            $user = "root";
            $password = "";
            $database = "pointsale";
            $charset = "utf8";
            $pdo = new pdo("mysql:host={$host};dbname={$database};charset={$charset}", $user, $password);
            
            @$total_venta=$_POST['total_venta'];
            @$cambio=$_POST['cambio'];
            @$pago=$_POST['pago'];
                                   
    
    //-------------------- TERMINA EXISTENCIAS ----------------//
                                   
            if(isset($_POST['insertar'])){
            
           $insertarventa=$pdo->query("insert into ventas value(null,'$pago','$total_venta','$cambio',now())");

        }
        if(isset($_POST['cancelar'])){
            $cancelarventa=$pdo->query("DELETE FROM preventa");
        }
?>
<?php
if (isset($_GET["accion"]) && $_GET["accion"]=="editar"):
    require("model/articulos.php");
    $articulo = @Articulos::getArticulo($_GET["codigo_articulo"]);
?>
    <div class="page-content-header">
        <h3>
            <i class="zmdi zmdi-book"></i>
        Articulo
        <small>Actualizar Datos</small>
        </h3>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <div class="box box-blue">
                    <div class="box-body">
                        <form id="form" method="post">
                            <p class="text-secondary">Datos del Articulo</p>
                            <hr>
                            <div class="form-group">
                                <input type="text" class="form-control d-none" id="codigo_articulo" name="codigo_articulo" value="<?php echo $articulo["codigo_articulo"]; ?>">
                            </div>
                             <div class="form-group">
                                <input type="text" class="form-control d-none" id="clave_articulo" name="clave_articulo" value="<?php echo $articulo["clave_articulo"]; ?>">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control d-none" id="descripcion_sat" name="descripcion_sat" value="<?php echo $articulo["descripcion_sat"]; ?>">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control d-none" id="marca" name="marca" value="<?php echo $articulo["marca"]; ?>">
                            </div>
                            <div class="form-group">
                                <label for="descripcion_articulo" class="col-sm-2 col-form-label text-center">Descripción:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="descripcion_articulo" name="descripcion_articulo" value="<?php echo $articulo["descripcion_articulo"]; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="unidad" class="col-sm-2 col-form-label text-center">Unidad:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="unidad" name="unidad" value="<?php echo $articulo["unidad"]; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="codigo_barra" class="col-sm-2 col-form-label text-center">Codigo de barra:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="codigo_barra" name="codigo_barra" value="<?php echo $articulo["codigo_barra"]; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="precio_m" class="col-sm-2 col-form-label text-center">Precio de Mayoreo:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="precio_m" name="precio_m" value="<?php echo $articulo["precio_m"]; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="precio_d" class="col-sm-2 col-form-label text-center">Precio de Distribuidor:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="precio_d" name="precio_d" value="<?php echo $articulo["precio_d"]; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="precio_s" class="col-sm-2 col-form-label text-center">Precio de Subdistribuidor:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="precio_s" name="precio_s" value="<?php echo $articulo["precio_s"]; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="precio_p" class="col-sm-2 col-form-label text-center">Precio al Publico:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="precio_p" name="precio_p" value="<?php echo $articulo["precio_p"]; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="codigo_sat" class="col-sm-2 col-form-label text-center">Codigo SAT:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="codigo_sat" name="codigo_sat" value="<?php echo $articulo["codigo_sat"]; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="cantidad" class="col-sm-2 col-form-label text-center">Cantidad en existencia:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="cantidad" name="cantidad" value="<?php echo $articulo["cantidad"]; ?>">
                                </div>
                            </div>
                            <hr>
                            <div class="text-center">
                                <button id="editarticulo" class="btn btn-primary btn-sm"><i class="fa fa-folder-o fa-lg"></i> Actualizar</button>
                                <a href="./?view=articulos" class="btn btn-sm btn-success"><i class="zmdi zmdi-mall"></i> Articulos</a>
                            </div>
                         </form>
                    </div>
                </div>
            </div>
         </div>
    </div>

<!-- //////////////////////////////////////////////////////////// -->

<?php
elseif (isset($_GET["accion"]) && $_GET["accion"]=="listar"):
    require("model/articulos.php");
    $articulo = @Articulos::getArticulo2($_GET["codigo_articulo"]);
?>
<div class="page-content-header">
    <div class="btn-group pull-right">
    </div>
    <h3>
        <i class="zmdi zmdi-face"></i>
        Información del SAT
        <!-- <small>Datos</small> -->
    </h3>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="box box-blue">
                <div class="box-body">
                    <div class="table_responsive">
                      <table class="table table-bordered text-center">
                        <thead>
                            <tr>
                            <td><b>Codigo SAT</b></td>
                            <td><b>Descripción Sat</b></td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
    // foreach ($articulos as $articulo)
                        {
                        ?>
                        <tr>
                            <td><?php echo $articulo['codigo_sat']; ?></td>
                            <td><?php echo $articulo['descripcion_sat']; ?></td>
                        </tr>
                        <?php
                        }
                        ?>
                        </tbody>
                       </table>      
                    </div>
                    <a href="./?view=articulos" class="btn btn-sm btn-success"><i class="zmdi zmdi-assignment-return"></i> Articulos</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
endif;
?>