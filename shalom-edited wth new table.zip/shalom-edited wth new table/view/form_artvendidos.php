<div class="page-content-header">
        <h3>
            <i class="zmdi zmdi-seat"></i>
        Articulos de la compra
        <!-- <small>Actualizar Datos</small> -->
        </h3>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-6">
                <div class="box box-blue">
                    <div class="box-body">
<!--  -->
<?php
// echo "<table style='border: solid 1px black;'>";
echo "<div class='table_responsive'><table class='table table-bordered text-center'>";
// echo "<tr><th>Articulos</th><th>cantidad</th><th>precio</th><th>monto</th></tr>";
echo "<tr style='background-color:green; color:white; font-weight: bold;'><td><b>Articulos</b></td><td><b>Cantidad</b></td><td><b>Precio</b></td><td><b>Monto</b></td></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pointsale";
// $codigo_barra = $_GET['codigo_barra'];
 try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $id_venta = $_GET['id_venta'];
    $stmt = $conn->prepare(" select descripcion_articulo,cantidad_p,precio_pro,monto_p from productos_vendidos inner join articulos on productos_vendidos.producto_vendido=articulos.codigo_barra where venta='$id_venta'");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo utf8_encode($v);
    }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";
?> 

 </div>
                </div>
            </div>
         </div>
    </div>
<!--  -->
                    
                   
                       