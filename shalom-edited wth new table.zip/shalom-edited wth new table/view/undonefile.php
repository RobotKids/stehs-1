<?php
    require("model/articulos.php");
    $articulos = Articulos::getArticulo($_GET["codigo_articulo"]);
?>
    <div class="page-content-header">
        <h3>
            <i class="zmdi zmdi-book"></i>
        Clientes
        <small>Actualizar Datos</small>
        </h3>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <div class="box box-blue">
                    <div class="box-body">
                        <form id="form" method="post">
                            <p class="text-secondary">Datos del Cliente</p>
                            <hr>
                            <div class="form-group">
                                <input type="text" class="form-control d-none" id="codigo_articulo" name="codigo_articulo" value="<?php echo $articulos["codigo_articulo"]; ?>">
                            </div>
                            <div class="form-group">
                                <label for="codigo_barra" class="col-sm-2 col-form-label text-center">Nombre:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="codigo_barra" name="codigo_barra" value="<?php echo $articulos["codigo_barra"]; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="nombre_marca" class="col-sm-2 col-form-label text-center">Nombre:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <!-- <div class="input-group-addon"><i class="zmdi zmdi-comment-image"></i></div> -->
                                   <select  class="form-control" name="marca" id="marca">
                              

                              dfghjuikooooooooooooooooooooooooooooooooooooooooooooooo    
                              <?php
    require("model/articulos.php");
    $articulos = Articulos::getArticulo($_GET["codigo_articulo"]);
?>
    <div class="page-content-header">
        <h3>
            <i class="zmdi zmdi-book"></i>
        Clientes
        <small>Actualizar Datos</small>
        </h3>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <div class="box box-blue">
                    <div class="box-body">
                        <form id="form" method="post">
                            <p class="text-secondary">Datos del Cliente</p>
                            <hr>
                            <div class="form-group">
                                <input type="text" class="form-control d-none" id="codigo_articulo" name="codigo_articulo" value="<?php echo $articulos["codigo_articulo"]; ?>">
                            </div>
                            <div class="form-group">
                                <label for="codigo_barra" class="col-sm-2 col-form-label text-center">Nombre:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="codigo_barra" name="codigo_barra" value="<?php echo $articulos["codigo_barra"]; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="nombre_marca" class="col-sm-2 col-form-label text-center">Nombre:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <!-- <div class="input-group-addon"><i class="zmdi zmdi-comment-image"></i></div> -->
                                   <select  class="form-control" name="marca" id="precio">
                                            <option value="mayoreo">Mayoreo</option>
                                            <option value="distribuidor">Distribuidor</option>
                                            <option value="subdistribuidor">Subdistribuidor</option>
                                            <option value="lista">Lista</option>
                                    </select>
                               </div> 
                            </div>
                            <div class="form-group" id="opcion1">
                                <label for="codigo_barra" class="col-sm-2 col-form-label text-center">precio:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="codigo_barra" name="codigo_barra" value="<?php echo $articulos["precio_m"]; ?>">
                                </div>
                            </div>
                            <p id="p1"></p>
                            <hr>
                            <div class="text-center">
                                <button id="editMarca" class="btn btn-primary btn-sm"><i class="fa fa-folder-o fa-lg"></i> Actualizar</button>
                                <a href="./?view=marcas" class="btn btn-sm btn-success"><i class="zmdi zmdi-account"></i> Marcas</a>
                                
                            </div>
                         </form>
                    </div>
                </div>
            </div>
         </div>
    </div>

<!-- //////////////////////////////////////////////////////////// -->
<script type="text/javascript">

  var seleccion=document.getElementById('precio');
  var parrafo=document.getElementById('p1');

  seleccion.addEventListener('change',getPrecio);

  function getPrecio(){
    var obtener=seleccion.value;
    swich(obtener){
        case 'mayoreo':
        parrafo.textContent='mayoreo';
        break;
        case 'distribuidor':
        parrafo.textContent='distribuidor';
        break;
        default;
        parrafo.textContent='';

    }
  }
</script>          <!-- <option onclick="distibuidor()">Mayoreo</option> -->
                                            <option onclick="distibuidor()">Distribuidor</option>
                                            <option>Subdistribuidor</option>
                                            <option onclick="Lista()" id="opcion2">Lista</option>
                                    </select>
                               </div> 
                            </div>
                            <div class="form-group">
                                <label for="codigo_barra" class="col-sm-2 col-form-label text-center">precio:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="codigo_barra" name="codigo_barra" value="<?php echo $articulos["precio_m"]; ?>">
                                </div>
                            </div>

                            <hr>
                            <div class="text-center">
                                <button id="editMarca" class="btn btn-primary btn-sm"><i class="fa fa-folder-o fa-lg"></i> Actualizar</button>
                                <a href="./?view=marcas" class="btn btn-sm btn-success"><i class="zmdi zmdi-account"></i> Marcas</a>
                                
                            </div>
                         </form>
                    </div>
                </div>
            </div>
         </div>
    </div>

<!-- //////////////////////////////////////////////////////////// -->
<script type="text/javascript">
    function Lista(){
            var x=document.getElementById('opcion1');
            alert('Lista');
    }
    function distibuidor(){
        var y=document.getElementById('opcion2');
        alert('Mayoreo');
    }
</script>

<!-- dfghjuikooooooooooooooooooooooooooooooooooooooooooooooo -->
<?php
    require("model/articulos.php");
    $articulos = Articulos::getArticulo($_GET["codigo_articulo"]);
?>
    <div class="page-content-header">
        <h3>
            <i class="zmdi zmdi-book"></i>
        Clientes
        <small>Actualizar Datos</small>
        </h3>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <div class="box box-blue">
                    <div class="box-body">
                        <form id="form" method="post">
                            <p class="text-secondary">Datos del Cliente</p>
                            <hr>
                            <div class="form-group">
                                <input type="text" class="form-control d-none" id="codigo_articulo" name="codigo_articulo" value="<?php echo $articulos["codigo_articulo"]; ?>">
                            </div>
                            <div class="form-group">
                                <label for="codigo_barra" class="col-sm-2 col-form-label text-center">Nombre:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="codigo_barra" name="codigo_barra" value="<?php echo $articulos["codigo_barra"]; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="nombre_marca" class="col-sm-2 col-form-label text-center">Nombre:</label>
                                <div class="input-group mb-2 mb-sm-0">
                                    <!-- <div class="input-group-addon"><i class="zmdi zmdi-comment-image"></i></div> -->
                                   <select  class="form-control" name="marca" id="precio">
                                            <option value="mayoreo">Mayoreo</option>
                                            <option value="distribuidor">Distribuidor</option>
                                            <option value="subdistribuidor">Subdistribuidor</option>
                                            <option value="lista">Lista</option>
                                    </select>
                               </div> 
                            </div>
                            <div class="form-group" id="opcion1">
                                <label for="codigo_barra" class="col-sm-2 col-form-label text-center">precio:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="codigo_barra" name="codigo_barra" value="<?php echo $articulos["precio_m"]; ?>">
                                </div>
                            </div>
                            <p id="p1"></p>
                            <hr>
                            <div class="text-center">
                                <button id="editMarca" class="btn btn-primary btn-sm"><i class="fa fa-folder-o fa-lg"></i> Actualizar</button>
                                <a href="./?view=marcas" class="btn btn-sm btn-success"><i class="zmdi zmdi-account"></i> Marcas</a>
                                
                            </div>
                         </form>
                    </div>
                </div>
            </div>
         </div>
    </div>

<!-- //////////////////////////////////////////////////////////// -->
<script type="text/javascript">

  var seleccion=document.getElementById('precio');
  var parrafo=document.getElementById('p1');

  seleccion.addEventListener('change',getPrecio);

  function getPrecio(){
    var obtener=seleccion.value;
    swich(obtener){
        case 'mayoreo':
        parrafo.textContent='mayoreo';
        break;
        case 'distribuidor':
        parrafo.textContent='distribuidor';
        break;
        default;
        parrafo.textContent='';

    }
  }
</script>