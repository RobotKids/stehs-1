<?php

    require("conexion.php");

    class Articulos
    {
        public function getArticulos()
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->query("select codigo_articulo,clave_articulo,descripcion_articulo,unidad,codigo_barra,precio_m,precio_d,precio_s,precio_p,nombre_marca,cantidad from articulos inner join marcas on articulos.marca=marcas.id_marca");
            return $consulta;
        }

        public function getArticulos2()
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->query("select codigo_articulo,codigo_barra from articulos");
            return $consulta;
        }
        // falta !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        // public function getAlumno2()
        public function getArticulo2($codigo_articulo)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("select * from articulos where codigo_articulo = :codigo_articulo");
            // $consulta = $conexion->query('select * from alumnos inner join tutores on alumnos.id_tutor=tutores.id_tutor inner join padres on alumnos.id_padre=padres.id_padre where id_proveedor = :id_proveedor');
           $consulta->bindParam(':codigo_articulo', $codigo_articulo, PDO::PARAM_INT);
           $consulta->execute();
           return $consulta->fetch();
           // return $consulta;
        }
       
        //falta !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        
        public function getArticulo($codigo_articulo)
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("select * from articulos where codigo_articulo = :codigo_articulo");
            $consulta->bindParam(":codigo_articulo", $codigo_articulo, PDO::PARAM_INT);
            $consulta->execute();
            return $consulta->fetch();
        } 
        
        public function insertArticulo($codigo_articulo, $clave_articulo, $descripcion_articulo, $unidad, $codigo_barra, $precio_m, $precio_d, $precio_s, $precio_p, $codigo_sat, $descripcion_sat, $marca, $cantidad)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("insert into articulos value(:codigo_articulo, :clave_articulo, :descripcion_articulo, :unidad, :codigo_barra, :precio_m, :precio_d, :precio_s, :precio_p, :codigo_sat, :descripcion_sat, :marca, :cantidad)");
            $consulta->bindParam(":codigo_articulo", $codigo_articulo, PDO::PARAM_INT);
            $consulta->bindParam(":clave_articulo", $clave_articulo, PDO::PARAM_STR);
            $consulta->bindParam(":descripcion_articulo", $descripcion_articulo, PDO::PARAM_STR);
            $consulta->bindParam(":unidad", $unidad, PDO::PARAM_STR);
            $consulta->bindParam(":codigo_barra", $codigo_barra, PDO::PARAM_STR);
            $consulta->bindParam(":precio_m", $precio_m, PDO::PARAM_STR);
            $consulta->bindParam(":precio_d", $precio_d, PDO::PARAM_STR);
            $consulta->bindParam(":precio_s", $precio_s, PDO::PARAM_STR);
            $consulta->bindParam(":precio_p", $precio_p, PDO::PARAM_STR);
            $consulta->bindParam(":codigo_sat", $codigo_sat, PDO::PARAM_STR);
            $consulta->bindParam(":descripcion_sat", $descripcion_sat, PDO::PARAM_STR);
            $consulta->bindParam(":marca", $marca, PDO::PARAM_INT);
            $consulta->bindParam(":cantidad", $cantidad, PDO::PARAM_STR);
            return $consulta->execute();   
        }
        
        public function updateArticulo($codigo_articulo, $clave_articulo, $descripcion_articulo, $unidad, $codigo_barra, $precio_m, $precio_d, $precio_s, $precio_p, $codigo_sat, $descripcion_sat, $marca, $cantidad)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("update articulos set clave_articulo = :clave_articulo, descripcion_articulo = :descripcion_articulo, unidad = :unidad, codigo_barra = :codigo_barra, precio_m = :precio_m, precio_d = :precio_d, precio_s = :precio_s, precio_p = :precio_p, codigo_sat = :codigo_sat,descripcion_sat = :descripcion_sat, marca = :marca, cantidad = :cantidad where codigo_articulo = :codigo_articulo");
            $consulta->bindParam(":codigo_articulo", $codigo_articulo, PDO::PARAM_INT);
            $consulta->bindParam(":clave_articulo", $clave_articulo, PDO::PARAM_STR);
            $consulta->bindParam(":descripcion_articulo", $descripcion_articulo, PDO::PARAM_STR);
            $consulta->bindParam(":unidad", $unidad, PDO::PARAM_STR);
            $consulta->bindParam(":codigo_barra", $codigo_barra, PDO::PARAM_STR);
            $consulta->bindParam(":precio_m", $precio_m, PDO::PARAM_STR);
            $consulta->bindParam(":precio_d", $precio_d, PDO::PARAM_STR);
            $consulta->bindParam(":precio_s", $precio_s, PDO::PARAM_STR);
            $consulta->bindParam(":precio_p", $precio_p, PDO::PARAM_STR);
            $consulta->bindParam(":codigo_sat", $codigo_sat, PDO::PARAM_STR);
            $consulta->bindParam(":descripcion_sat", $descripcion_sat, PDO::PARAM_STR);
            $consulta->bindParam(":marca", $marca, PDO::PARAM_INT);
            $consulta->bindParam(":cantidad", $cantidad, PDO::PARAM_STR);
            return $consulta->execute();
        }
        
        public function deleteArticulo($codigo_articulo)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("delete from articulos where codigo_articulo = :codigo_articulo");
            $consulta->bindParam(":codigo_articulo", $codigo_articulo, PDO::PARAM_INT);
            return $consulta->execute();
        }

        public function lookArticulo($codigo_barra)
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("SELECT * FROM `articulos` WHERE `codigo_barra` =  :codigo_barra");
            $consulta->bindParam(":codigo_barra", $codigo_barra, PDO::PARAM_STR);
            $consulta->execute();
            return $consulta->fetch();
        }

    }

    //$alumnos = Alumno::deleteAlumno(3); se elimina un alumno por id

   // $alumnos = Alumno::updateAlumno(1, "prueba", "prueba", "prueba", "prueba", "prueba", 1, "a", "prueba", "prueba");   //sirvera para actualizar un alumno por id
    
   // $alumnos = Alumno::insertAlumno("prueba", "prueba", "prueba", "prueba", "prueba", 1, "a", "prueba", "prueba");  //asi se insertan datos

   // $alumnos = Alumno::getAlumno(2);   //sirve para consultar los alumnos agregados o el id de un alumno
   // foreach ($alumnos as $alumno)
   // {
       // print_r($alumno);
   // }