<?php

    require("conexion.php");

    class Exis
    {
        public function getPreventas()
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->query("select * from preventa inner join articulos on preventa.cod_articulo=articulos.codigo_barra");
            
            return $consulta;
        }
        // falta !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        // public function getAlumno2()
        public function getArticulo2($codigo_articulo)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("select * from articulos where codigo_articulo = :codigo_articulo");
            // $consulta = $conexion->query('select * from alumnos inner join tutores on alumnos.id_tutor=tutores.id_tutor inner join padres on alumnos.id_padre=padres.id_padre where id_proveedor = :id_proveedor');
           $consulta->bindParam(':codigo_articulo', $codigo_articulo, PDO::PARAM_INT);
           $consulta->execute();
           return $consulta->fetch();
           // return $consulta;
        }
       
        //falta !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        
        public function getArticulo($codigo_articulo)
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("select * from articulos where codigo_articulo = :codigo_articulo");
            $consulta->bindParam(":codigo_articulo", $codigo_articulo, PDO::PARAM_INT);
            $consulta->execute();
            return $consulta->fetch();
        } 
        
        // public function insertPreventas($codigo_barra, $precio, $cantidad, $monto)
        public function insertExis($num1, $num2)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("insert into existencias value(null, :codigo_barra, :cantidad)");
            $consulta->bindParam(":codigo_barra", $num1, PDO::PARAM_STR);
            $consulta->bindParam(":cantidad", $num2, PDO::PARAM_STR);
            return $consulta->execute();   
        }

        public function insertMarcas($nombre_marca)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("insert into marcas value(null, :nombre_marca)");
            $consulta->bindParam(":nombre_marca", $nombre_marca, PDO::PARAM_STR);
            return $consulta->execute();   
        }
        
        public function deletePreventas($id_preventa)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("delete from preventa where id_preventa = :id_preventa");
            $consulta->bindParam(":id_preventa", $id_preventa, PDO::PARAM_INT);
            return $consulta->execute();
        }

    }

    //$alumnos = Alumno::deleteAlumno(3); se elimina un alumno por id

   // $alumnos = Alumno::updateAlumno(1, "prueba", "prueba", "prueba", "prueba", "prueba", 1, "a", "prueba", "prueba");   //sirvera para actualizar un alumno por id
    
   // $alumnos = Alumno::insertAlumno("prueba", "prueba", "prueba", "prueba", "prueba", 1, "a", "prueba", "prueba");  //asi se insertan datos

   // $alumnos = Alumno::getAlumno(2);   //sirve para consultar los alumnos agregados o el id de un alumno
   // foreach ($alumnos as $alumno)
   // {
       // print_r($alumno);
   // }