create database pointsale;
use pointsale;

create table clientes(
    id_cliente int (3) not null auto_increment primary key,
    nombre_cliente varchar (30) not null,
    domicilio_cliente varchar (30) not null,
    telefono_cliente varchar (11) not null
);

create table proveedores(
    id_proveedor int (3) not null auto_increment primary key,
    nombre_proveedor varchar (15) not null,
    telefono_proveedor varchar (12) not null,
    direccion varchar (30) not null
);

create table articulos(
    codigo_articulo int (7) not null primary key,
    clave_articulo varchar (10) not null,
    descripcion_articulo text not null,
    unidad varchar(15) not null,
    codigo_barra varchar (20) not null,
    precio_m decimal (10,2) not null,
    precio_d decimal (10,2) not null,
    precio_s decimal (10,2) not null,
    precio_p decimal (10,2) not null,
    codigo_sat varchar (20) not null,
    descripcion_sat text not null,
    marca int (3) not null,
    cantidad int (8) not null
);

create table marcas(
    id_marca int (3) not null auto_increment primary key,
    nombre_marca varchar (15) not null
);

create table usuarios(
    id_usuario int not null auto_increment primary key,
    usuario varchar(20),
    password varchar(20)
);

create table preventa(
    id_preventa int (3) not null auto_increment primary key,
    cod_articulo varchar (15) not null,
    cantidad int not null,
    precio decimal (10,2) not null,
    monto decimal (10,2) not null
);

create table ventas(
    id_venta int (15) not null auto_increment primary key,
    total_venta decimal (10,2) not null,
    fecha_venta date not null
);

create table productos_vendidos(
    id_pv int (3) not null auto_increment primary key,
    venta int (3) not null,
    producto_vendido varchar (15) not null,
    cantidad_p varchar (15) not null,
    precio_pro varchar (15) not null,
    monto_p varchar (15) not null
);

create table max2(
    id_max2 int (3) not null auto_increment primary key,
    max2 int (3) not null
);
