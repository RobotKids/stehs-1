<?php

    require("conexion.php");

    class Marcas 
    {
        public function getMarcas()
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->query("select * from marcas");
            return $consulta;
        }

        public function getMarca($id_marca)
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("select * from marcas where id_marca = :id_marca");
            $consulta->bindParam(":id_marca", $id_marca, PDO::PARAM_INT);
            $consulta->execute();
            return $consulta->fetch();
        }
        
        public function insertMarcas($nombre_marca)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("insert into marcas value(null, :nombre_marca)");
            $consulta->bindParam(":nombre_marca", $nombre_marca, PDO::PARAM_STR);
            return $consulta->execute();   
        }
        
        public function updateMarcas($id_marca, $nombre_marca)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("update marcas set nombre_marca = :nombre_marca where id_marca = :id_marca");
            $consulta->bindParam(":id_marca", $id_marca, PDO::PARAM_INT);
            $consulta->bindParam(":nombre_marca", $nombre_marca, PDO::PARAM_STR);
            return $consulta->execute();
        }
        
        public function deleteMarcas($id_marca)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("delete from marcas where id_marca = :id_marca");
            $consulta->bindParam(":id_marca", $id_marca, PDO::PARAM_INT);
            return $consulta->execute();
        }
    }

    //$alumnos = Alumno::deleteAlumno(3); se elimina un alumno por id

   // $alumnos = Alumno::updateAlumno(1, "prueba", "prueba", "prueba", "prueba", "prueba", 1, "a", "prueba", "prueba");   //sirvera para actualizar un alumno por id
    
   // $alumnos = Alumno::insertAlumno("prueba", "prueba", "prueba", "prueba", "prueba", 1, "a", "prueba", "prueba");  //asi se insertan datos

   // $alumnos = Alumno::getAlumno(2);   //sirve para consultar los alumnos agregados o el id de un alumno
   // foreach ($alumnos as $alumno)
   // {
       // print_r($alumno);
   // }