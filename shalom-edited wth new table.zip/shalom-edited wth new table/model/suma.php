<?php

    require("conexion.php");

    class Sumas
    {
        public function suma(){
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta="SELECT SUM(monto) as Total FROM preventa";
            $resultado=$conexion -> query($consulta);
            $fila=$resultado->fetch(); 
            return $fila;
        }

        public function getArticulo($codigo_articulo)
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("select * from articulos where codigo_articulo = :codigo_articulo");
            $consulta->bindParam(":codigo_articulo", $codigo_articulo, PDO::PARAM_INT);
            $consulta->execute();
            return $consulta->fetch();
        }
        public function yes(){
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta="SELECT descripcion_articulo as Total FROM articulos where codigo_articulo=123";
            $resultado=$conexion -> query($consulta);
            $fila=$resultado->fetch(); 
            return $fila;
        }
        public function getyes($codigo_articulo)
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("SELECT descripcion_articulo as Total FROM articulos where codigo_articulo = :codigo_articulo");
            $consulta->bindParam(":codigo_articulo", $codigo_articulo, PDO::PARAM_INT);
            $consulta->execute();
            return $consulta->fetch();
        }

    
    }
  
