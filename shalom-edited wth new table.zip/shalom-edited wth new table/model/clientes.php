<?php

    require("conexion.php");

    class Clientes 
    {
        public function getClientes()
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->query("select * from clientes");
            return $consulta;
        }
        // falta !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        // public function getAlumno2()
        public function getAlumno2($id_proveedor)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("select * from alumnos inner join tutores on alumnos.tutor_id=tutores.id_tutor inner join padres on alumnos.padre_id=padres.id_padre where id_proveedor = :id_proveedor");
            // $consulta = $conexion->query('select * from alumnos inner join tutores on alumnos.id_tutor=tutores.id_tutor inner join padres on alumnos.id_padre=padres.id_padre where id_proveedor = :id_proveedor');
           $consulta->bindParam(':id_proveedor', $id_proveedor, PDO::PARAM_INT);
           $consulta->execute();
           return $consulta->fetch();
           // return $consulta;
        }
       
        //falta !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        
        public function getCliente($id_cliente)
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("select * from clientes where id_cliente = :id_cliente");
            $consulta->bindParam(":id_cliente", $id_cliente, PDO::PARAM_INT);
            $consulta->execute();
            return $consulta->fetch();
        }
        
        public function insertClientes($nombre_cliente, $telefono_cliente,$domicilio_cliente)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("insert into clientes value(null, :nombre_cliente, :telefono_cliente, :domicilio_cliente)");
            $consulta->bindParam(":nombre_cliente", $nombre_cliente, PDO::PARAM_STR);
            $consulta->bindParam(":telefono_cliente", $telefono_cliente, PDO::PARAM_STR);
            $consulta->bindParam(":domicilio_cliente", $domicilio_cliente, PDO::PARAM_STR);
            return $consulta->execute();   
        }
        
        public function updateClientes($id_cliente, $nombre_cliente, $telefono_cliente, $domicilio_cliente)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("update clientes set nombre_cliente = :nombre_cliente, telefono_cliente = :telefono_cliente, domicilio_cliente = :domicilio_cliente where id_cliente = :id_cliente");
            $consulta->bindParam(":id_cliente", $id_cliente, PDO::PARAM_INT);
            $consulta->bindParam(":nombre_cliente", $nombre_cliente, PDO::PARAM_STR);
            $consulta->bindParam(":telefono_cliente", $telefono_cliente, PDO::PARAM_STR);
            $consulta->bindParam(":domicilio_cliente", $domicilio_cliente, PDO::PARAM_STR);
            return $consulta->execute();
        }
        
        public function deleteClientes($id_cliente)
        {
            $modelo = new Conexion();
            $conexion = $modelo->conectar();
            $consulta = $conexion->prepare("delete from clientes where id_cliente = :id_cliente");
            $consulta->bindParam(":id_cliente", $id_cliente, PDO::PARAM_INT);
            return $consulta->execute();
        }
    }

    //$alumnos = Alumno::deleteAlumno(3); se elimina un alumno por id

   // $alumnos = Alumno::updateAlumno(1, "prueba", "prueba", "prueba", "prueba", "prueba", 1, "a", "prueba", "prueba");   //sirvera para actualizar un alumno por id
    
   // $alumnos = Alumno::insertAlumno("prueba", "prueba", "prueba", "prueba", "prueba", 1, "a", "prueba", "prueba");  //asi se insertan datos

   // $alumnos = Alumno::getAlumno(2);   //sirve para consultar los alumnos agregados o el id de un alumno
   // foreach ($alumnos as $alumno)
   // {
       // print_r($alumno);
   // }