<?php

    class Conexion
    {
        public function conectar()
        {
            $host = "localhost";
            $user = "root";
            $password = "";
            $database = "pointsale";
            $charset = "utf8";
            
            $pdo = new pdo("mysql:host={$host};dbname={$database};charset={$charset}", $user, $password);
            return $pdo;
        }
    }
