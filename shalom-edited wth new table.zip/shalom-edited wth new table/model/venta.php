<?php

    require("conexion.php");

    class Ventas 
    {
        public function getVentas()
        {
            $modelo = new Conexion;
            $conexion = $modelo->conectar();
            $consulta = $conexion->query("select * from ventas");
            return $consulta;
        }

        

    }

 