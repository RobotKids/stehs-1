<?php
    if ($_GET)
    {
        $action = $_GET["action"];
        if (function_exists($action))
        {
            require("../model/preventa.php");
            call_user_func($action);
        }
    }

    function listar()
    {
        $preventa = new Preventas();
        $result = $preventa->getPreventas();
        
        if (!$result)
        {
            die("no hay registros");
        }
        else
        {
            while($data = $result->fetch())
            {
                $datos["data"][] =$data;
            }
            echo json_encode($datos); 
        }
    }
    function guardar()
    {
        $num1 = $_POST["num1"];
        $num2 = $_POST["num2"];
        $modelo = new Exis();
        $result = $modelo->insertExis($num1, $num2);
        echo $result;
    }

    function eliminar()
    {
        $id_preventa = $_POST["id_preventa"];
        $preventa = new Preventas();
        $result = $preventa->deletePreventas($id_preventa);
        echo $result;
    }

