<?php
    if ($_GET)
    {
        $action = $_GET["action"];
        if (function_exists($action))
        {
            require("../model/clientes.php");
            call_user_func($action);
        }
    }

    function listar()
    {
        $clientes = new Clientes();
        $result = $clientes->getClientes();
        
        if (!$result)
        {
            die("no hay registros");
        }
        else
        {
            while($data = $result->fetch())
            {
                $datos["data"][] =$data;
            }
            echo json_encode($datos);
            
        }
    }

    function guardar()
    {
        $nombre_cliente = $_POST["nombre_cliente"];
        $telefono_cliente = $_POST["telefono_cliente"];
        $domicilio_cliente = $_POST["domicilio_cliente"];
        $modelo = new Clientes();
        $result = $modelo->insertClientes($nombre_cliente, $telefono_cliente, $domicilio_cliente);
        echo $result;
    }


    function editar()
    {
        $id_cliente = $_POST["id_cliente"];
        $nombre_cliente = $_POST["nombre_cliente"];
        $telefono_cliente = $_POST["telefono_cliente"];
        $domicilio_cliente = $_POST["domicilio_cliente"];       
        $clientes = new Clientes();
        $result = $clientes->updateClientes($id_cliente, $nombre_cliente, $telefono_cliente, $domicilio_cliente);
        echo $result;
    }

    function eliminar()
    {
        $id_cliente = $_POST["id_cliente"];
        $cliente = new Clientes();
        $result = $cliente->deleteClientes($id_cliente);
        echo $result;
    }