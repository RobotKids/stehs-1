<?php
    if ($_GET)
    {
        $action = $_GET["action"];
        if (function_exists($action))
        {
            require("../model/preventa.php");
            call_user_func($action);
        }
    }

    function listar()
    {
        $preventa = new Preventas();
        $result = $preventa->getPreventas();
        
        if (!$result)
        {
            die("no hay registros");
        }
        else
        {
            while($data = $result->fetch())
            {
                $datos["data"][] =$data;
            }
            echo json_encode($datos); 
        }
    }
    function guardar()
    {
        $codigo_barra = $_POST["codigo_barra"];
        $precio = $_POST["precio"];
        $cantidad = $_POST["cantidad"];
        $existencia=$_POST["result_E"];
        // $monto = $_POST["monto"];
        $modelo = new Preventas();
        $result = $modelo->insertPreventas($codigo_barra, $precio, $cantidad,$existencia);
        echo $result;
    }

    function eliminar()
    {
        $id_preventa = $_POST["id_preventa"];
        $preventa = new Preventas();
        $result = $preventa->deletePreventas($id_preventa);
        echo $result;
    }

